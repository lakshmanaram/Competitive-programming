#include <bits/stdc++.h>
using namespace std;
int main(){
    ifstream infile;
    ofstream outfile;
    long long t;
    infile.open("B-small-attempt0.in");
    outfile.open("B-output.out");
    infile>>t;
    for(long long tk=1;tk<=t;tk++){
        long long a,b,n,k;
        long long mod = 1000000007;
        infile>>a>>b>>n>>k;
        long long ans = 0;
        for(int i =1; i<=n; i++){
            long long val = pow(i,a);
            for(int j=1;j<=n;j++) {
                if(i!=j){
                    long long val2 = pow(j,b);
                    if((val+val2) % k == 0){
                        ans++;
                        ans %= mod;
                    }
                }
            }
        }
        outfile<<"Case #"<<tk<<": "<<ans;
        outfile<<endl;
    }
    infile.close();
    outfile.close();
    return 0;
}
